# JevForWechat A0

目标环境：Android 15 + 微信 Android 8.0.78 + 无 Root + LSPatch 1.2 / Vector runtime。

## 这一版只做什么

A0 是“先把最难的入口跑通”的诊断版：

1. 只注入 `com.tencent.mm`。
2. 捕获最近一次有文字内容的长按 View。
3. 当微信出现一个含“翻译”且同时含“复制/转发/收藏/引用/删除”等字样的 `PopupWindow` 时，在“翻译”旁边尝试加入“Jev分析”。
4. 点“Jev分析”只在本机 Toast 显示捕获到的文字。

**A0 不联网，不需要 API Key，也不会把聊天内容发给任何服务器。**

这样做的目的，是先验证微信 8.0.78 当前构建的长按菜单是不是 `PopupWindow`，以及被长按消息的文字能不能通过通用 View 路径拿到。验证通过后，A1 再接 OpenRouter/Jev，并把结果做成消息下方的内嵌卡片。

## 为什么不用写死微信混淆类名

8.0.78 有不止一个官方构建，混淆/内部类可能变化。A0 先 Hook Android 自己的 `View.performLongClick()` 与 `PopupWindow.show*()`，只在微信进程生效，并通过菜单文字特征识别“聊天消息长按菜单”。这样比直接写死微信内部类更适合作为第一轮探针。

## 构建

建议环境：

- Android Studio 当前稳定版，或直接使用仓库内的 GitHub Actions
- JDK 17
- Gradle 9.6.0
- Android SDK 37 / Build Tools 36.0.0

用 Android Studio 直接打开项目，等待 Gradle Sync 完成，然后点 **Build → Build APK(s)**。

这个工程没有捆绑 Gradle Wrapper 二进制文件。GitHub Actions 已固定使用 Gradle 9.6.0；如果在 Android Studio 本地打开，也请使用兼容的 Gradle 环境。

手机无电脑构建请看 `GITHUB_PHONE_BUILD.md`。

输出通常在：

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 无 Root 加载

使用支持 Android 15 的 LSPatch 1.2 系列。

测试时建议使用测试环境/不重要的微信账号。LSPatch 会修改并重新签名目标 APK；不能把它当作官方原版微信的无风险更新。微信升级后也可能需要重新 Patch。

典型流程：

1. 构建本模块 APK。
2. 准备与你手机架构一致的官方微信 8.0.78 APK。
3. 在 LSPatch 中 Patch 微信，并把本模块作为 embedded/integrated module 加入。
4. 安装 patched 微信。
5. 打开聊天，长按一条普通文字消息。
6. 如果菜单里出现“Jev分析”，点击后应看到 `Jev 已捕获：...` 的 Toast。

> 如果“Jev分析”没有出现，不要继续接 API。先记录：长按菜单截图 + LSPatch 日志/Android logcat 中 `JevForWechat` 的日志。A1 会根据实际菜单容器补 `Dialog`/自定义 Popup 的探针。

## 预期结果

成功：

```text
复制 | 转发 | 收藏 | 翻译 | Jev分析 | ...
```

点击后：

```text
Jev 已捕获：你长按的那条文字...
```

## 下一版 A1

A0 跑通后再做：

- OpenRouter -> Jev 分析；
- 不弹 Dialog；
- 结果真正嵌入该消息下面，随消息滚动；
- 再点一次可收起/刷新；
- 后续才加 DeepSeek 回复和自动模式。
