plugins {
    id("com.android.application")
}

android {
    namespace = "dev.jev.wechat"
    compileSdk = 37

    defaultConfig {
        applicationId = "dev.jev.wechat"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-a0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    // Provided by LSPatch / Vector at runtime; do not package it into the APK.
    compileOnly("io.github.libxposed:api:102.0.0")
}
