package dev.jev.wechat;

import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * A0 goal:
 * 1) Load only inside com.tencent.mm.
 * 2) Remember the view that was long-pressed.
 * 3) When a WeChat-looking PopupWindow containing “翻译” appears, append “Jev分析”.
 * 4) Clicking it only shows the captured text locally (no network/API yet).
 *
 * This deliberately avoids hard-coding obfuscated WeChat class names so that the
 * first probe has a chance to work across 8.0.78 point builds. It is a diagnostic
 * milestone, not the finished embedded-analysis UI.
 */
public final class ModuleMain extends XposedModule {
    private static final String TAG = "JevForWechat";
    private static final String TARGET = "com.tencent.mm";
    private static final String MENU_LABEL = "Jev分析";

    private static volatile View lastLongPressedView;
    private static volatile String lastLongPressedText = "";
    private static volatile long lastLongPressAt = 0L;
    private static final AtomicBoolean installed = new AtomicBoolean(false);

    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        log(Log.INFO, TAG, "module loaded in process=" + param.getProcessName());
    }

    @Override
    public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {
        if (!TARGET.equals(param.getPackageName())) return;
        if (!installed.compareAndSet(false, true)) return;

        log(Log.INFO, TAG, "installing A0 hooks for " + TARGET);
        try {
            installLongPressCapture();
            installPopupHooks();
            log(Log.INFO, TAG, "A0 hooks installed");
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "A0 hook install failed", t);
        }
    }

    private void installLongPressCapture() throws Exception {
        Method performLongClick = View.class.getDeclaredMethod("performLongClick");
        performLongClick.setAccessible(true);

        hook(performLongClick)
                .setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                .intercept(chain -> {
                    Object self = chain.getThisObject();
                    if (self instanceof View) {
                        View view = (View) self;
                        String text = extractText(view);
                        if (!text.isEmpty()) {
                            lastLongPressedView = view;
                            lastLongPressedText = text;
                            lastLongPressAt = SystemClock.uptimeMillis();
                            log(Log.INFO, TAG, "captured long press text=" + trim(text, 120));
                        }
                    }
                    return chain.proceed();
                });
    }

    private void installPopupHooks() throws Exception {
        hookPopupMethod("showAtLocation", View.class, int.class, int.class, int.class);
        hookPopupMethod("showAsDropDown", View.class);
        hookPopupMethod("showAsDropDown", View.class, int.class, int.class);
        hookPopupMethod("showAsDropDown", View.class, int.class, int.class, int.class);
    }

    private void hookPopupMethod(String name, Class<?>... args) throws Exception {
        Method method = PopupWindow.class.getDeclaredMethod(name, args);
        method.setAccessible(true);
        hook(method)
                .setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                .intercept(chain -> {
                    Object result = chain.proceed();
                    Object self = chain.getThisObject();
                    if (self instanceof PopupWindow) {
                        PopupWindow popup = (PopupWindow) self;
                        View content = popup.getContentView();
                        if (content != null) {
                            content.post(() -> tryInjectMenuItem(popup));
                        }
                    }
                    return result;
                });
    }

    private void tryInjectMenuItem(PopupWindow popup) {
        try {
            if (SystemClock.uptimeMillis() - lastLongPressAt > 2500L) return;
            View content = popup.getContentView();
            if (content == null) return;

            TextView translate = findTextView(content, "翻译");
            if (translate == null) return;
            if (!containsAnyText(content, "复制", "转发", "收藏", "引用", "删除")) return;
            if (findTextView(content, MENU_LABEL) != null) return;

            ViewParentInfo p = parentOf(translate);
            if (p == null) return;

            TextView jev = cloneMenuTextView(translate);
            jev.setText(MENU_LABEL);
            jev.setOnClickListener(v -> {
                try {
                    popup.dismiss();
                } catch (Throwable ignored) {
                }
                View anchor = lastLongPressedView;
                String text = lastLongPressedText;
                if (anchor != null) {
                    Toast.makeText(anchor.getContext(),
                            text.isEmpty() ? "Jev：没有读取到文字" : "Jev 已捕获：" + trim(text, 80),
                            Toast.LENGTH_LONG).show();
                }
            });

            int insertAt = Math.min(p.index + 1, p.parent.getChildCount());
            ViewGroup.LayoutParams lp = copyLayoutParams(translate);
            if (lp != null) {
                p.parent.addView(jev, insertAt, lp);
            } else {
                p.parent.addView(jev, insertAt);
            }
            log(Log.INFO, TAG, "inserted Jev menu item");
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "menu injection failed", t);
        }
    }

    private static TextView cloneMenuTextView(TextView src) {
        TextView out = new TextView(src.getContext());
        out.setTextColor(src.getTextColors());
        out.setTextSize(TypedValue.COMPLEX_UNIT_PX, src.getTextSize());
        out.setGravity(src.getGravity() == Gravity.NO_GRAVITY ? Gravity.CENTER : src.getGravity());
        out.setPadding(src.getPaddingLeft(), src.getPaddingTop(), src.getPaddingRight(), src.getPaddingBottom());
        out.setMinWidth(src.getMinWidth());
        out.setMinHeight(src.getMinHeight());
        out.setSingleLine(src.isSingleLine());
        Drawable bg = src.getBackground();
        if (bg != null) out.setBackground(bg.getConstantState() != null ? bg.getConstantState().newDrawable() : bg);
        return out;
    }

    private static ViewGroup.LayoutParams copyLayoutParams(View src) {
        ViewGroup.LayoutParams lp = src.getLayoutParams();
        if (lp == null) return null;
        if (lp instanceof LinearLayout.LayoutParams) {
            return new LinearLayout.LayoutParams((LinearLayout.LayoutParams) lp);
        }
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            return new ViewGroup.MarginLayoutParams((ViewGroup.MarginLayoutParams) lp);
        }
        return new ViewGroup.LayoutParams(lp);
    }

    private static ViewParentInfo parentOf(View view) {
        if (!(view.getParent() instanceof ViewGroup)) return null;
        ViewGroup parent = (ViewGroup) view.getParent();
        return new ViewParentInfo(parent, parent.indexOfChild(view));
    }

    private static TextView findTextView(View root, String exact) {
        if (root instanceof TextView) {
            CharSequence cs = ((TextView) root).getText();
            if (cs != null && exact.contentEquals(cs.toString().trim())) return (TextView) root;
        }
        if (root instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) root;
            for (int i = 0; i < g.getChildCount(); i++) {
                TextView hit = findTextView(g.getChildAt(i), exact);
                if (hit != null) return hit;
            }
        }
        return null;
    }

    private static boolean containsAnyText(View root, String... values) {
        for (String value : values) {
            if (findTextView(root, value) != null) return true;
        }
        return false;
    }

    private static String extractText(View root) {
        StringBuilder sb = new StringBuilder();
        Deque<View> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty() && sb.length() < 800) {
            View v = queue.removeFirst();
            if (v instanceof TextView) {
                CharSequence cs = ((TextView) v).getText();
                if (cs != null) {
                    String s = cs.toString().trim();
                    if (!s.isEmpty()) {
                        if (sb.length() > 0) sb.append('\n');
                        sb.append(s);
                    }
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) queue.addLast(g.getChildAt(i));
            }
        }
        return sb.toString().trim();
    }

    private static String trim(String s, int max) {
        if (s == null) return "";
        String oneLine = s.replace('\n', ' ').replace('\r', ' ').trim();
        return oneLine.length() <= max ? oneLine : oneLine.substring(0, max) + "…";
    }

    private static final class ViewParentInfo {
        final ViewGroup parent;
        final int index;
        ViewParentInfo(ViewGroup parent, int index) {
            this.parent = parent;
            this.index = index;
        }
    }
}
