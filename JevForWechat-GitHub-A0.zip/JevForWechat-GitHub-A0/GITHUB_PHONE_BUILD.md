# 只用手机，通过 GitHub Actions 生成 APK

这个版本已经带好 `.github/workflows/build-apk.yml`，GitHub 会在云端编译 APK。

## 最省事的方式

如果你把 GitHub 连接给 ChatGPT，可以让我帮你把这些项目文件放进一个仓库。连接 GitHub 需要你自己确认授权。

如果你自己操作 GitHub：

1. 新建一个仓库，例如 `JevForWechat`。
2. 把本项目的**全部文件和目录**上传到仓库根目录。注意：不能只把 `JevForWechat-GitHub-A0.zip` 当成一个文件上传，因为 GitHub Actions 看不到压缩包里面的工程。
3. 上传后打开仓库的 **Actions**。
4. 找到 **Build Android APK**。
5. 点 **Run workflow**。
6. 构建完成后进入这次运行记录，在 **Artifacts** 里下载 `JevForWechat-A0-debug`。
7. 解压 Artifact，里面就是 `app-debug.apk`。

以后只要代码有更新并推送到 `main` 或 `master`，它也会自动重新构建。

## 构建环境

- JDK 17
- Gradle 9.6.0
- Android Gradle Plugin 9.4.0
- compileSdk 37
- Android Build Tools 36.0.0

这些版本按 AGP 9.4.0 的官方兼容要求固定。

## A0 版本用途

A0 目前只验证：

`长按微信文字消息 -> 微信长按菜单尝试出现“Jev分析” -> 点击后 Toast 显示捕获到的文字`

它不会联网，也不会使用 OpenRouter/DeepSeek API。
